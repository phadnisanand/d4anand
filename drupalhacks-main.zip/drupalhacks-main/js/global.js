(function ($, Drupal, drupalSettings) {

  'use strict';

  Drupal.behaviors.drupalhacksGlobal = {
    attach: function (context, settings) {

      // $('a').css('color', 'red');
      // alert(settings.abc);

    }
  };

})(jQuery, Drupal, drupalSettings);
