(function ($, Drupal) {

    $.fn.datacheck = function() {
        alert("working");
        $("#custom-user-details-form").submit();
    };

}(jQuery, Drupal));
